// Kamil Zambrowski
// Matthew Jaros
// I Pledge My Honor That I Have Abided By The Stevens Honor System



public enum ApparatusType {
	LEGPRESSMACHINE, BARBELL, HACKSQUATMACHINE,
	LEGEXTENSIONMACHINE, LEGCURLMACHINE, LATPULLDOWNMACHINE,
	PECDECKMACHINE, CABLECROSSOVERMACHINE;
}