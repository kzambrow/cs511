// Kamil Zambrowski
// Matthew Jaros
// I Pledge My Honor That I Have Abided By The Stevens Honor System


public enum WeightPlateSize {
	SMALL_3KG, MEDIUM_5KG, LARGE_10KG;
}
